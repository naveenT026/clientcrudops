using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;  // Required for configuration
using System;
using System.Collections.Generic; // Required for List
using System.Data.SqlClient; // Required for SQL access

namespace cruddemo.Pages.Employee
{
    public class IndexModel : PageModel
    {
        private readonly IConfiguration _configuration;  // Dependency Injection to get config
        public List<EmployeeInfo> listEmployee = new List<EmployeeInfo>();

        public IndexModel(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public void OnGet()
        {
            try
            {
                // Fetch the connection string from appsettings.json
                string connectionString = _configuration.GetConnectionString("DefaultConnection");

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sql = "SELECT * FROM emp";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                EmployeeInfo employeeInfo = new EmployeeInfo();
                                employeeInfo.eid = "" + reader.GetInt32(0);
                                employeeInfo.ename = reader.GetString(1);
                               employeeInfo.email = reader.GetString(2);
                                employeeInfo.phone = reader.GetString(3);
                                employeeInfo.address = reader.GetString(4);
                                employeeInfo.created_at = reader.GetDateTime(5).ToString();

                                listEmployee.Add(employeeInfo);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: " + ex.ToString());
            }
        }
    }
    public class EmployeeInfo
    {
        public String eid;
        public String ename;
        public String email;
        public String phone;
        public String address;
        public String created_at;
    }
}
