using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;  // Required for configuration
using System;
using System.Collections.Generic; // Required for List
using System.Data.SqlClient; // Required for SQL access

namespace cruddemo.Pages.Student
{
    public class IndexModel : PageModel
    {
        private readonly IConfiguration _configuration;  // Dependency Injection to get config
        public List<StudentInfo> listStudents = new List<StudentInfo>();

        public IndexModel(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public void OnGet()
        {
            try
            {
                // Fetch the connection string from appsettings.json
                string connectionString = _configuration.GetConnectionString("DefaultConnection");

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sql = "SELECT * FROM students";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                StudentInfo studentInfo = new StudentInfo();
                                studentInfo.sid = "" + reader.GetInt32(0);
                                studentInfo.sname = reader.GetString(1);
                                studentInfo.email = reader.GetString(2);
                                studentInfo.age = reader.GetString(3);
                                studentInfo.grade = reader.GetString(4);
                                studentInfo.created_at = reader.GetDateTime(5).ToString();

                                listStudents.Add(studentInfo);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: " + ex.ToString());
            }
        }
    }


    public class StudentInfo
    {
        public String sid;
        public String sname;
        public String email;
        public String age;
        public String grade;
        public String created_at;
    }
}