using cruddemo.Pages.Clients;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace cruddemo.Pages.Student
{
    public class EditModel : PageModel
    {
        public StudentInfo studentInfo = new StudentInfo();
        public String errorMessage = "";
        public String successMessage = "";

        public void OnGet()
        {
            String sid = Request.Query["sid"];

            try
            {
                String connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\NaveenKumar\\OneDrive - KALPITA TECHNOLOGIES PRIVATE LIMITED\\Documents\\demodb.mdf\";Integrated Security=True;Connect Timeout=30";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sql = "SELECT * FROM students WHERE sid=@sid";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@sid", sid);
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                studentInfo.sid = "" + reader.GetInt32(0);
                               studentInfo.sname = reader.GetString(1);
                                studentInfo.email = reader.GetString(2);
                                studentInfo.age = reader.GetString(3);
                                studentInfo.grade = reader.GetString(4);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                errorMessage = ex.Message;
            }
        }

        public void OnPost()
        {
            studentInfo.sid = Request.Form["id"];
            studentInfo.sname = Request.Form["name"];
            studentInfo.email = Request.Form["email"];
            studentInfo.age = Request.Form["age"];
            studentInfo.grade = Request.Form["grade"];

            if (studentInfo.sid.Length == 0 || studentInfo.sname.Length == 0 ||
                studentInfo.email.Length == 0 || studentInfo.age.Length == 0 ||
                studentInfo.grade.Length == 0)
            {
                errorMessage = "All fields are required";
                return;
            }

            try
            {
                String connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\NaveenKumar\\OneDrive - KALPITA TECHNOLOGIES PRIVATE LIMITED\\Documents\\demodb.mdf\";Integrated Security=True;Connect Timeout=30";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sql = "UPDATE students " +
                                 "SET sname=@sname, email=@email, age=@age, grade=@grade " +
                                 "WHERE sid=@sid";

                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@sname", studentInfo.sname);
                        command.Parameters.AddWithValue("@email", studentInfo.email);
                        command.Parameters.AddWithValue("@age", studentInfo.age);
                        command.Parameters.AddWithValue("@grade", studentInfo.grade);
                        command.Parameters.AddWithValue("@sid", studentInfo.sid);

                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                errorMessage = ex.Message;
                return;
            }

            Response.Redirect("/Student/Index");
        }
    }
}
