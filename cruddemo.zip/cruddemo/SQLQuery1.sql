﻿CREATE TABLE students (
    sid INT NOT NULL PRIMARY KEY IDENTITY,
    sname VARCHAR (100) NOT NULL,
    email VARCHAR (150) NOT NULL UNIQUE,
    age VARCHAR(20) NULL,
    grade VARCHAR(100) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO students(sname, email, age, grade)
VALUES
('Bill Gates', 'bill.gates@microsoft.com', '14', '10'),
('Elon Musk', 'elon.musk@spacex.com', '16', '12'),
('Will Smith', 'will.smith@gmail.com', '15', '11'),
('Bob Marley', 'bob@gmail.com', '14', '10'),
('Cristiano Ronaldo', 'cristiano.ronaldo@gmail.com', '16', '12'),
('Boris Johnson', 'boris.johnson@gmail.com', '14', '10');